#ifndef MK1MF_BUILD
# define CFLAGS        "-DB_ENDIAN"
# define PLATFORM      "macos"
# define DATE          "Sun Feb 27 19:44:16 MET 2000"
#endif
